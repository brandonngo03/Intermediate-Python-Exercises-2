# main.py

from BankAccount import BankAccount

# Instantiate a BankAccount
account = BankAccount("John Doe", 1000)

# Deposit some money
account.deposit(500)

# Withdraw some money
account.withdraw(200)

# Print the balance
print(account.get_balance())